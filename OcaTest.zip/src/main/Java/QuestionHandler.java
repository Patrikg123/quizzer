import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.sql.*;
import java.util.*;

/**
 * Created by Elev1 on 2016-08-02.
 */
@Named()
@SessionScoped
public class QuestionHandler implements Serializable{
    private int score;
    private int counter = 1;
    private String answer;
    private String question = PickQuestion(this.counter);
    private String correctanswer = PickCorrAnswer(this.counter);
    private String answerA = PickAnswerA(this.counter);
    private String answerB = PickAnswerB(this.counter);
    private String answerC = PickAnswerC(this.counter);
    private String answerD = PickAnswerD(this.counter);

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
public QuestionHandler(){

}

    public String getAnswerA() {
        return answerA;
    }

    public void setAnswerA(String answerA) {
        this.answerA = answerA;
    }

    public String getAnswerB() {
        return answerB;
    }

    public void setAnswerB(String answerB) {
        this.answerB = answerB;
    }

    public String getAnswerC() {
        return answerC;
    }

    public void setAnswerC(String answerC) {
        this.answerC = answerC;
    }

    public String getAnswerD() {
        return answerD;
    }

    public void setAnswerD(String answerD) {
        this.answerD = answerD;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getCorrectanswer() {
        return correctanswer;
    }

    public void setCorrectanswer(String correctanswer) {
        this.correctanswer = correctanswer;
    }

    public void UpdateScore(){
        if(this.answer.equals(this.correctanswer))
            this.score = this.score + 1;
        else
            this.score = this.score + 0;

    }

    public String LoadQuestion(){
        UpdateScore();
        if(this.counter < QuestionUpdater.GetCounter(1)){
            this.counter = this.counter + 1;

        }
        else {
            this.counter = 0;
            return "resultat.xhtml";
        }
        String question = PickQuestion(this.counter);
        String correctanswer = PickCorrAnswer(this.counter);
        String answerA = PickAnswerA(this.counter);
        String answerB = PickAnswerB(this.counter);
        String answerC = PickAnswerC(this.counter);
        String answerD = PickAnswerD(this.counter);
        this.correctanswer = correctanswer;

        this.question = question;
        this.answerA = answerA;
        this.answerB = answerB;
        this.answerC = answerC;
        this.answerD = answerD;


        return "index.xhtml";
    }

    //ListAnswers



    private String PickQuestion(int questionid){
        String Question ="";
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
                con = DriverManager.getConnection("jdbc:postgresql://localhost/ocadb", "postgres", "delllenovo");

                stmt = con.createStatement();

                String sql = "SELECT q.question as quest FROM questions q WHERE q.id =" + questionid + ";";
                // stmt.executeUpdate(sql);
                System.out.println(sql);
                rs = stmt.executeQuery(sql);

            while (rs.next()){
                             Question = rs.getString("quest");
                             System.out.println(rs.getString("quest"));}


                // sql = "DROP TABLE EMPLOYEES";
                //stmt.executeUpdate(sql);

        } catch (SQLException sqlex) {
            while (sqlex != null) {
                System.err.println("SQL error : " + sqlex.getMessage());
                System.err.println("SQL state : " + sqlex.getSQLState());
                System.err.println("Error code: " + sqlex.getErrorCode());
                System.err.println("Cause: " + sqlex.getCause());
                sqlex = sqlex.getNextException();
            }
        }finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) { /* ignored */}
            }
        }



        return Question;
    }



    public String Restart(){

        this.score = 0;
        this.counter = 1;
        // för att förhindra att sista frågan återupprepas körs LoadQuestion istället för index.xhtml

        String question = PickQuestion(this.counter);
        String correctanswer = PickCorrAnswer(this.counter);
        this.correctanswer = correctanswer;

        this.question = question;

        String answerA = PickAnswerA(this.counter);
        String answerB = PickAnswerB(this.counter);
        String answerC = PickAnswerC(this.counter);
        String answerD = PickAnswerD(this.counter);

        this.answerA = answerA;
        this.answerB = answerB;
        this.answerC = answerC;
        this.answerD = answerD;



        return "index.xhtml";


    }

    private String PickCorrAnswer(int questionid){

        String answerToPick = "";
        String answerToPick2 ="";
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;



        try {
                con = DriverManager.getConnection("jdbc:postgresql://localhost/ocadb", "postgres", "delllenovo");

                stmt = con.createStatement();

                String sql = "SELECT q.answer1 as answ FROM questions q WHERE q.id =" + questionid + ";";
            // stmt.executeUpdate(sql);
                System.out.println(sql);
                rs = stmt.executeQuery(sql);

            if (rs.next()){
                answerToPick = rs.getString("answ");
                System.out.println(rs.getString("answ"));}

            String sql2 = "SELECT a." + answerToPick +" as answ2 FROM answers a Where a.id=" + questionid + ";";
            System.out.println(sql2);
            ResultSet rs2 = stmt.executeQuery(sql2);
            if (rs2.next())
                answerToPick2 = rs2.getString("answ2");


            // sql = "DROP TABLE EMPLOYEES";
            //stmt.executeUpdate(sql);

        } catch (SQLException sqlex) {
            while (sqlex != null) {
                System.err.println("SQL error : " + sqlex.getMessage());
                System.err.println("SQL state : " + sqlex.getSQLState());
                System.err.println("Error code: " + sqlex.getErrorCode());
                System.err.println("Cause: " + sqlex.getCause());
                sqlex = sqlex.getNextException();
            }
        }finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) { /* ignored */}
            }
        }



        return answerToPick2;
    }

    private String PickAnswerA(int questionid){

        String answA = "";
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;




        try {
                con = DriverManager.getConnection("jdbc:postgresql://localhost/ocadb", "postgres", "delllenovo");

                stmt = con.createStatement();

                String sql = "SELECT a.answera as answ FROM answers a WHERE a.id =" + questionid + ";";
            // stmt.executeUpdate(sql);
                System.out.println(sql);
                rs = stmt.executeQuery(sql);

            if (rs.next()){
                answA = rs.getString("answ");
                System.out.println(rs.getString("answ"));}


        } catch (SQLException sqlex) {
            while (sqlex != null) {
                System.err.println("SQL error : " + sqlex.getMessage());
                System.err.println("SQL state : " + sqlex.getSQLState());
                System.err.println("Error code: " + sqlex.getErrorCode());
                System.err.println("Cause: " + sqlex.getCause());
                sqlex = sqlex.getNextException();
            }
        }finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) { /* ignored */}
            }
        }




        return answA;
    }

    private String PickAnswerB(int questionid){

        String answB = "";
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;




        try {
                con = DriverManager.getConnection("jdbc:postgresql://localhost/ocadb", "postgres", "delllenovo");

                stmt = con.createStatement();

                String sql = "SELECT a.answerb as answ FROM answers a WHERE a.id =" + questionid + ";";
            // stmt.executeUpdate(sql);
                System.out.println(sql);
                rs = stmt.executeQuery(sql);

            if (rs.next()){
                answB = rs.getString("answ");
                System.out.println(rs.getString("answ"));}


        } catch (SQLException sqlex) {
            while (sqlex != null) {
                System.err.println("SQL error : " + sqlex.getMessage());
                System.err.println("SQL state : " + sqlex.getSQLState());
                System.err.println("Error code: " + sqlex.getErrorCode());
                System.err.println("Cause: " + sqlex.getCause());
                sqlex = sqlex.getNextException();
            }
        }finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) { /* ignored */}
            }
        }



        return answB;
    }

    private String PickAnswerC(int questionid){

        String answC = "";
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;




        try {
                con = DriverManager.getConnection("jdbc:postgresql://localhost/ocadb", "postgres", "delllenovo");

                stmt = con.createStatement();

                String sql = "SELECT a.answerc as answ FROM answers a WHERE a.id =" + questionid + ";";
            // stmt.executeUpdate(sql);
                System.out.println(sql);
                rs = stmt.executeQuery(sql);

            if (rs.next()){
                answC = rs.getString("answ");
                System.out.println(rs.getString("answ"));}


        } catch (SQLException sqlex) {
            while (sqlex != null) {
                System.err.println("SQL error : " + sqlex.getMessage());
                System.err.println("SQL state : " + sqlex.getSQLState());
                System.err.println("Error code: " + sqlex.getErrorCode());
                System.err.println("Cause: " + sqlex.getCause());
                sqlex = sqlex.getNextException();
            }
        }finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) { /* ignored */}
            }
        }




        return answC;
    }
    private String PickAnswerD(int questionid){

        String answD = "";
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;




        try {
              con = DriverManager.getConnection("jdbc:postgresql://localhost/ocadb", "postgres", "delllenovo");

              stmt = con.createStatement();

            String sql = "SELECT a.answerd as answ FROM answers a WHERE a.id =" + questionid + ";";
            // stmt.executeUpdate(sql);
            System.out.println(sql);
              rs = stmt.executeQuery(sql);

            if (rs.next()){
                answD = rs.getString("answ");
                System.out.println(rs.getString("answ"));}


        } catch (SQLException sqlex) {
            while (sqlex != null) {
                System.err.println("SQL error : " + sqlex.getMessage());
                System.err.println("SQL state : " + sqlex.getSQLState());
                System.err.println("Error code: " + sqlex.getErrorCode());
                System.err.println("Cause: " + sqlex.getCause());
                sqlex = sqlex.getNextException();
            }
        }finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) { /* ignored */}
            }
        }



        return answD;
    }

    }





