import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.sql.*;

/**
 * Created by Elev1 on 2016-08-15.
 */
@Named()
@SessionScoped
public class QuestionUpdater implements Serializable {
    private String question;
    private String answera;
    private String answerb;
    private String answerc;
    private String answerd;
    private String correctanswer;

    public String getCorrectanswer() {
        return correctanswer;
    }

    public void setCorrectanswer(String correctanswer) {
        this.correctanswer = correctanswer;
    }

    public String getAnswerb() {
        return answerb;
    }

    public void setAnswerb(String answerb) {
        this.answerb = answerb;
    }

    public String getAnswerc() {
        return answerc;
    }

    public void setAnswerc(String answerc) {
        this.answerc = answerc;
    }

    public String getAnswerd() {
        return answerd;
    }

    public void setAnswerd(String answerd) {
        this.answerd = answerd;
    }

    public String getAnswera() {
        return answera;
    }

    public void setAnswera(String answera) {
        this.answera = answera;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public static void NewQuestion(String question, String correctanswer) {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
                con = DriverManager.getConnection("jdbc:postgresql://localhost/ocadb", "postgres", "delllenovo");
                stmt = con.createStatement();
                String sql = "INSERT INTO questions (question, answer1) VALUES (" + "\'" + question + "\', \'" +  correctanswer + "\');";
                System.out.println(sql);
                stmt.executeUpdate(sql);

                // ResultSet rs = stmt.executeQuery("SELECT \"BookID\" FROM \"Books\" WHERE \"BookID\" =" + bookid + ";");
                // while (rs.next())
                //     System.out.println(rs.getString("BookID"));


                // sql = "DROP TABLE EMPLOYEES";
                //stmt.executeUpdate(sql);

        } catch (SQLException sqlex) {
            while (sqlex != null) {
                System.err.println("SQL error : " + sqlex.getMessage());
                System.err.println("SQL state : " + sqlex.getSQLState());
                System.err.println("Error code: " + sqlex.getErrorCode());
                System.err.println("Cause: " + sqlex.getCause());
                sqlex = sqlex.getNextException();
            }
        }

        System.out.println("Sucess");
    }

    public String CreateNewQuestion(){
        int counter = GetCounter(1);


        NewQuestion(this.question, this.correctanswer);
        NewAnswers(this.answera, this.answerb, this.answerc, this.answerd);
        counter = counter +1;
        UpdateCounter(counter, 1);
        //NewCorrectAnswer(this.correctanswer);

        return "index.xhtml";
    }

    public static void NewAnswers(String answera, String answerb, String answerc, String answerd) {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            con = DriverManager.getConnection("jdbc:postgresql://localhost/ocadb", "postgres", "delllenovo");
            stmt = con.createStatement();
            String sql = "INSERT INTO answers (answera, answerb, answerc, answerd) VALUES (" + "\'" + answera + "\',"  + "\'" + answerb +"\'," + "\'" +   answerc+ "\'," + "\'" + answerd + "\');";
            System.out.println(sql);
            stmt.executeUpdate(sql);

            // ResultSet rs = stmt.executeQuery("SELECT \"BookID\" FROM \"Books\" WHERE \"BookID\" =" + bookid + ";");
            // while (rs.next())
            //     System.out.println(rs.getString("BookID"));


            // sql = "DROP TABLE EMPLOYEES";
            //stmt.executeUpdate(sql);

        } catch (SQLException sqlex) {
            while (sqlex != null) {
                System.err.println("SQL error : " + sqlex.getMessage());
                System.err.println("SQL state : " + sqlex.getSQLState());
                System.err.println("Error code: " + sqlex.getErrorCode());
                System.err.println("Cause: " + sqlex.getCause());
                sqlex = sqlex.getNextException();
            }
        }finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) { /* ignored */}
            }
        }

        System.out.println("Sucess");
    }








    public static void NewAnswerD(String answer) {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            con = DriverManager.getConnection("jdbc:postgresql://localhost/ocadb", "postgres", "delllenovo");
            stmt = con.createStatement();
            String sql = "INSERT INTO answers (answerd) VALUES (" + "\'" + answer + "\');";
            System.out.println(sql);
            stmt.executeUpdate(sql);

            // ResultSet rs = stmt.executeQuery("SELECT \"BookID\" FROM \"Books\" WHERE \"BookID\" =" + bookid + ";");
            // while (rs.next())
            //     System.out.println(rs.getString("BookID"));


            // sql = "DROP TABLE EMPLOYEES";
            //stmt.executeUpdate(sql);

        } catch (SQLException sqlex) {
            while (sqlex != null) {
                System.err.println("SQL error : " + sqlex.getMessage());
                System.err.println("SQL state : " + sqlex.getSQLState());
                System.err.println("Error code: " + sqlex.getErrorCode());
                System.err.println("Cause: " + sqlex.getCause());
                sqlex = sqlex.getNextException();
            }
        }finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) { /* ignored */}
            }
        }

        System.out.println("Sucess");
    }

   public static void NewCorrectAnswer(String question) {

       Connection con = null;
       Statement stmt = null;
       ResultSet rs = null;
        try {
            con = DriverManager.getConnection("jdbc:postgresql://localhost/ocadb", "postgres", "delllenovo");
            stmt = con.createStatement();
            String sql = "INSERT INTO questions (answer1) VALUES (" + "\'" + question + "\');";
            System.out.println(sql);
            stmt.executeUpdate(sql);

            // ResultSet rs = stmt.executeQuery("SELECT \"BookID\" FROM \"Books\" WHERE \"BookID\" =" + bookid + ";");
            // while (rs.next())
            //     System.out.println(rs.getString("BookID"));


            // sql = "DROP TABLE EMPLOYEES";
            //stmt.executeUpdate(sql);

        } catch (SQLException sqlex) {
            while (sqlex != null) {
                System.err.println("SQL error : " + sqlex.getMessage());
                System.err.println("SQL state : " + sqlex.getSQLState());
                System.err.println("Error code: " + sqlex.getErrorCode());
                System.err.println("Cause: " + sqlex.getCause());
                sqlex = sqlex.getNextException();
            }
        }finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) { /* ignored */}
            }
        }

        System.out.println("Sucess");
    }




    public static int GetCounter(int counterid){
        int counter = 0;
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
             con = DriverManager.getConnection("jdbc:postgresql://localhost/ocadb", "postgres", "delllenovo");

            stmt = con.createStatement();

            String sql = "SELECT c.value as cval FROM counters c WHERE c.id =" + counterid + ";";
            // stmt.executeUpdate(sql);
            System.out.println(sql);
            rs = stmt.executeQuery(sql);

            while (rs.next()){
                counter = rs.getInt("cval");
                System.out.println(rs.getInt("cval"));}


            // sql = "DROP TABLE EMPLOYEES";
            //stmt.executeUpdate(sql);


        } catch (SQLException sqlex) {
            while (sqlex != null) {
                System.err.println("SQL error : " + sqlex.getMessage());
                System.err.println("SQL state : " + sqlex.getSQLState());
                System.err.println("Error code: " + sqlex.getErrorCode());
                System.err.println("Cause: " + sqlex.getCause());
                sqlex = sqlex.getNextException();
            }
        }finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) { /* ignored */}
            }
        }



        return counter;



    }
    public static void UpdateCounter(int counter, int id) {

        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            con = DriverManager.getConnection("jdbc:postgresql://localhost/ocadb", "postgres", "delllenovo");
            stmt = con.createStatement();
            String sql = "UPDATE counters SET value=" +counter + " WHERE id=" +id +";";
            System.out.println(sql);
            stmt.executeUpdate(sql);

            // ResultSet rs = stmt.executeQuery("SELECT \"BookID\" FROM \"Books\" WHERE \"BookID\" =" + bookid + ";");
            // while (rs.next())
            //     System.out.println(rs.getString("BookID"));


            // sql = "DROP TABLE EMPLOYEES";
            //stmt.executeUpdate(sql);

        } catch (SQLException sqlex) {
            while (sqlex != null) {
                System.err.println("SQL error : " + sqlex.getMessage());
                System.err.println("SQL state : " + sqlex.getSQLState());
                System.err.println("Error code: " + sqlex.getErrorCode());
                System.err.println("Cause: " + sqlex.getCause());
                sqlex = sqlex.getNextException();
            }
        }finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) { /* ignored */}
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) { /* ignored */}
            }
        }

        System.out.println("Sucess");
    }
}





